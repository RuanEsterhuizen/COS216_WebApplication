<footer class = "footer">			
	<ul class="leftSide">
		<li> <a href = "https://wheatley.cs.up.ac.za/u23532387/">eKhaya Properties</a></li>
	</ul>

	<ul class="rightSide">
		<li> <button id="darkmode">Dark Mode</button></li>
	</ul>
</footer>

<script src="footer.js"></script>