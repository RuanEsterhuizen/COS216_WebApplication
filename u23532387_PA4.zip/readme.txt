DEFAULT LOGIN CREDENTIALS:
username: tony@starkindustries.com
password: LoveYou3000

HOW TO USE
1.	Open the PA4 landing page from the launch page
2.	Without logging in, you can only view listings and use the calculators
3.	To use the rest of the website, you need to click "login" in the header and enter your credentials
4.	If you don't have an account yet, click on "register" first to create an account
5.	After creating an account and/or logging in, you can save search, set appearances and add favourties

FUNCTIONALITY NOT IMPLIMENTED
-	Dark mode does not save to user account
-	Dark mode does not apply accross entire site
-	PHP api used for everything, accept for getting listings and agentcies
